﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using NativeWebSocket;

public class TouchpointManager : MonoBehaviour
{
	WebSocket websocket;

	[Header("UI Elements")]
	public TextMeshProUGUI idleText;
	public TextMeshProUGUI welcomeText;
	public TextMeshProUGUI statementText;
	public TextMeshProUGUI progressText;

	private string touchpointId = "touchpoint-1";
	public string serverUrl = "wss://web-production-76d43.up.railway.app/ws";

	private List<System.Action> mainThreadActions = new List<System.Action>();

	void Start()
	{
		ShowIdle();
		StartCoroutine(ConnectWebSocket());
	}

	IEnumerator ConnectWebSocket()
	{
		websocket = new WebSocket(serverUrl);

		websocket.OnOpen += () =>
		{
			Debug.Log("connected");
			string msg = "{\"event\":\"register-touchpoint\",\"touchpointId\":\"" + touchpointId + "\"}";
			websocket.SendText(msg);
		};

		websocket.OnMessage += (bytes) =>
		{
			string raw = System.Text.Encoding.UTF8.GetString(bytes);
			Debug.Log("received: " + raw);
			lock(mainThreadActions)
			{
				mainThreadActions.Add(() => HandleMessage(raw));
			}
		};

		websocket.OnError += (error) =>
		{
			Debug.Log("error: " + error);
		};

		websocket.OnClose += (code) =>
		{
			Debug.Log("closed");
		};

		var connectTask = websocket.Connect();
		yield return new WaitUntil(() => connectTask.IsCompleted);
	}

	void Update()
	{
		if (websocket != null)
		{
			websocket.DispatchMessageQueue();
		}

		lock(mainThreadActions)
		{
			if (mainThreadActions.Count > 0)
			{
				foreach (var action in mainThreadActions)
				{
					action.Invoke();
				}
				mainThreadActions.Clear();
			}
		}
	}

	void HandleMessage(string raw)
	{
		Debug.Log("handling: " + raw);
		if (raw.Contains("user-checkin") || raw.Contains("user-update"))
		{
			UserUpdateMessage msg = JsonUtility.FromJson<UserUpdateMessage>(raw);
			if (msg != null && msg.data != null)
			{
				ShowActive(msg.data);
			}
		}
		else if (raw.Contains("touchpoint-idle"))
		{
			ShowIdle();
		}
	}

	void ShowIdle()
	{
		idleText.gameObject.SetActive(true);
		welcomeText.gameObject.SetActive(false);
		statementText.gameObject.SetActive(false);
		progressText.gameObject.SetActive(false);
		idleText.text = "Scan to interact\n" + serverUrl.Replace("wss://", "http://").Replace("/ws", "") + "/controller.html?tp=" + touchpointId;
	}

	void ShowActive(UserData data)
	{
		idleText.gameObject.SetActive(false);
		welcomeText.gameObject.SetActive(true);
		statementText.gameObject.SetActive(true);
		progressText.gameObject.SetActive(true);

		welcomeText.text = "Welcome " + data.username;
		statementText.text = data.fullStatement;
		progressText.text = data.completed 
			? "Congratulations! All 3 touchpoints visited!"
			: "Touchpoints visited: " + data.visitCount + "/3";
	}

	async void OnApplicationQuit()
	{
		await websocket.Close();
	}
}

[System.Serializable]
public class UserUpdateMessage
{
	public string evt;
	public UserData data;
}

[System.Serializable]
public class UserData
{
	public string username;
	public string fullStatement;
	public int visitCount;
	public bool completed;
}