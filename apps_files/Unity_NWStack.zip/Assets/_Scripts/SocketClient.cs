﻿using UnityEngine;
using System.Collections;
using NativeWebSocket;

public class SocketClient : MonoBehaviour
{
	WebSocket websocket;
	public string socketIP = "ws://192.168.10.162:3000";
	
    // Start is called once before the first execution of Update after the MonoBehaviour is created
	async void Start()
	{
		websocket = new WebSocket(socketIP);
		
		websocket.OnOpen += () => {
			Debug.Log("connected to server");
		};
		
		websocket.OnMessage += (bytes) => {
			string message = System.Text.Encoding.UTF8.GetString(bytes);
			Debug.Log("message received: " + message);
			
			//parse the color from the json
			ColorMessage parsed = JsonUtility.FromJson<ColorMessage>(message);
			if(parsed != null && parsed.color != null){
				Camera.main.backgroundColor = 
				(parsed.color == "red")? Color.red : 
				(parsed.color == "blue")? Color.blue :
					Color.black;
			}
		};
		
		websocket.OnError += (error) => {
			Debug.Log("error: "+error);
		};
		
		websocket.OnClose += (code) =>{
			Debug.Log("connection closed");
		};
		
		await websocket.Connect();
    }

    // Update is called once per frame
    void Update()
	{
#if !UNITY_WEBGL || UNITY_EDITOR
		websocket.DispatchMessageQueue();
#endif
	}
    
	async void OnApplicationQuit(){
		await websocket.Close();
	}
}

[System.Serializable]
public class ColorMessage{
	public string color;
}
