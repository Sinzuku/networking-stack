﻿/* SCRIPT INSPECTOR 3
 * version 3.1.11, December 2024
 * Copyright © 2012-2024, Flipbook Games
 *
 * Script Inspector 3 - World's Fastest IDE for Unity
 *
 *
 * Follow me on http://twitter.com/FlipbookGames
 * Like Flipbook Games on Facebook http://facebook.com/FlipbookGames
 * Join discussion in Unity forums http://forum.unity3d.com/threads/138329
 * Contact info@flipbookgames.com for feedback, bug reports, or suggestions.
 * Visit http://flipbookgames.com/ for more info.
 */


using ScriptInspector;

using UnityEngine;
using UnityEditor;
using System;
using System.Runtime.InteropServices;
using System.Collections.Generic;

[Serializable]
public class RecentLocation
{
	public string assetGuid;
	public int line;
	public int index;
}

[Serializable]
public class GlobalUndoRecord
{
	public List<string> guids;
	public List<int> changeIds;
}

[InitializeOnLoad, Serializable, DefaultExecutionOrder(-1000)]
public class FGTextBufferManager : ScriptableObject
{
	[SerializeField]
	private List<FGTextBuffer> allBuffers = new List<FGTextBuffer>();
	
	[SerializeField]
	private List<GlobalUndoRecord> globalUndoRecords = new List<GlobalUndoRecord>();
	[NonSerialized]
	private GlobalUndoRecord newGlobalUndoRecord;
	
	[SerializeField]
	public List<RecentLocation> recentLocations = new List<RecentLocation>();
	public static bool insertingTextAfterCaret = false;
	
	[SerializeField]
	public int recentLocationsOffset;
	
	[SerializeField]
	public string fullLineCopied;
	
	[SerializeField]
	private string symbolSearchText;
	public static string SymbolSearchText {
		get { return _instance.symbolSearchText; }
		set { _instance.symbolSearchText = value; }
	}
	
	private static bool reloadingAssemblies = false;
	
	public static bool IsReloadingAssemblies {
		get {
			return reloadingAssemblies;
		}
	}
	
	private static HashSet<string> pendingAssetImports = new HashSet<string>();
	
	private static Queue<string> asyncParseBuffers = new Queue<string>();

	static FGTextBufferManager()
	{
#if UNITY_2017_2_OR_NEWER
		EditorApplication.playModeStateChanged -= OnPlaymodeStateChanged;
		EditorApplication.playModeStateChanged += OnPlaymodeStateChanged;
#else
		EditorApplication.playmodeStateChanged -= OnPlaymodeStateChanged;
		EditorApplication.playmodeStateChanged += OnPlaymodeStateChanged;
#endif
		AppDomain.CurrentDomain.DomainUnload -= CurrentDomain_DomainUnload;
		AppDomain.CurrentDomain.DomainUnload += CurrentDomain_DomainUnload;
		
		AppDomain.CurrentDomain.ReflectionOnlyAssemblyResolve += ReflectionOnlyAssemblyResolve;
		
		EditorApplication.update += OnUpdate;
		EditorApplication.delayCall += CheckForNewVersion;
	}

	static System.Reflection.Assembly ReflectionOnlyAssemblyResolve(object sender, ResolveEventArgs args)
	{
		return System.Reflection.Assembly.ReflectionOnlyLoad(args.Name);
	}

	private void OnEnable()
	{
		//Debug.Log("Enabling <b>FGTextBufferManager</b> " + allBuffers.Count);
		hideFlags = HideFlags.HideAndDontSave;
		
		for (var i = allBuffers.Count; i --> 0; )
		{
			var buffer = allBuffers[i];
			if (buffer == null || !buffer.CanUndo() && !buffer.CanRedo())
			{
				allBuffers.RemoveAt(i);
				//Debug.Log("Removed buffer " + (buffer != null ? AssetDatabase.GUIDToAssetPath(buffer.guid) : "null"));
				
				if (buffer != null)
					DestroyImmediate(buffer);
			}
		}
		
		if (_instance == null)
		{
			//Debug.Log("OnEnable " + allBuffers.Count);
			//foreach (var buffer in allBuffers)
			//{
			//	Debug.Log("    " + AssetDatabase.GUIDToAssetPath(buffer.guid) + " " + buffer.undoPosition);
			//}
			
			_instance = this;
			foreach (var buffer in allBuffers)
			{
				if (buffer.IsModified)
				{
					asyncParseBuffers.Enqueue(buffer.guid);
				}
			}
		}
		else if (_instance != this)
		{
			Debug.LogWarning("Multiple Managers!!! Trying to resolve...");
			
			if (allBuffers.Count > 0)
			{
				//Debug.Log("this " + allBuffers.Count + " " + AssetDatabase.GUIDToAssetPath(allBuffers[0].guid));
				//Debug.Log("instance " + this.allBuffers.Count + " " + AssetDatabase.GUIDToAssetPath(_instance.allBuffers[0].guid));
				
				//var all = Resources.FindObjectsOfTypeAll<FGTextBufferManager>();
				//Debug.Log("    Count: " + all.Length);
				//foreach (var item in all)
				//{
				//	Debug.Log(item.allBuffers.Count);
				//	foreach (var buffer in item.allBuffers)
				//	{
				//		Debug.Log("    " + AssetDatabase.GUIDToAssetPath(buffer.guid) + " " + buffer.undoPosition);
				//	}
				//}
				
				for (var i = allBuffers.Count; i --> 0; )
				{
					var buffer = allBuffers[i];
					var existingBuffer = _instance.allBuffers.Find(x => x != null && x.guid == buffer.guid);
					if (existingBuffer == null)
					{
						_instance.allBuffers.Add(buffer);
						allBuffers.RemoveAt(i);
					}
					else
					{
						// TODO: Find out what to do in this case!
					}
				}
			}
			
			if (allBuffers.Count == 0)
			{
				Debug.Log("Multiple managers resolved successfully :)");
				DestroyImmediate(this);
			}
			else
			{
				Debug.LogWarning("Failed to resolve 'multiple managers'. :(");
			}
		}
		
		var script = MonoScript.FromScriptableObject(this);
		var path = AssetDatabase.GetAssetPath(script);
		if (string.IsNullOrEmpty(path))
			path = "Assets/Plugins/Editor/ScriptInspector3/Scripts/FGTextBufferManager.cs";
		path = System.IO.Path.GetDirectoryName(System.IO.Path.GetDirectoryName(path));
		path = System.IO.Path.Combine(path, ".gitignore");
		try { System.IO.File.WriteAllText(path, "*"); } catch {};
	}
	
	static void CurrentDomain_DomainUnload(object sender, EventArgs e)
	{
		if (reloadingAssemblies)
		{
			if (FGTextEditor.lastFocusedEditor != null)
				FGTextEditor.lastFocusedEditor.CloseAllPopups();
		}
		else
		{
			SaveAllModified(true);
		}
	}

	//[PostProcessScene]
	//private static void OnBuild()
	//{
	//    SaveAllModified(false);
	//    //AssetDatabase.SaveAssets();
	//}

#if UNITY_2017_2_OR_NEWER
	private static void OnPlaymodeStateChanged(PlayModeStateChange state)
	{
		if (_instance == null)
			return;

		if (state == PlayModeStateChange.ExitingEditMode)
			FGTextEditor.MenuReloadAssemblies();
	}
#else
	private static void OnPlaymodeStateChanged()
	{
		if (_instance == null)
			return;

		if (EditorApplication.isPlayingOrWillChangePlaymode && !EditorApplication.isPlaying)
			SaveAllModified(false);
	}
#endif
	
	public static void AddBufferToGlobalUndo(FGTextBuffer buffer)
	{
		if (Instance().newGlobalUndoRecord == null)
		{
			_instance.newGlobalUndoRecord = new GlobalUndoRecord();
			_instance.newGlobalUndoRecord.guids = new List<string>();
			_instance.newGlobalUndoRecord.changeIds = new List<int>();
		}
		
		_instance.newGlobalUndoRecord.guids.Add(buffer.guid);
		_instance.newGlobalUndoRecord.changeIds.Add(buffer.currentChangeId);
	}
	
	public static void RecordGlobalUndo()
	{
		if (Instance().newGlobalUndoRecord != null && _instance.newGlobalUndoRecord.guids.Count > 1)
		{
			_instance.globalUndoRecords.Add(_instance.newGlobalUndoRecord);
		}
		_instance.newGlobalUndoRecord = null;
	}
	
	public static bool GlobalUndo(FGTextBuffer buffer = null)
	{
		var globalUndoRecords = Instance().globalUndoRecords;
		if (globalUndoRecords.Count == 0)
			return false;
		
		if (buffer == null)
		{
			var lastRecord = globalUndoRecords[globalUndoRecords.Count - 1];
			var firstGuid = lastRecord.guids.FirstOrDefault();
			buffer = GetBuffer(firstGuid);
			if (buffer == null)
				return false;
		}
		
		for (var i = globalUndoRecords.Count; i --> 0; )
		{
			var record = globalUndoRecords[i];
			var index = record.guids.IndexOf(buffer.guid);
			if (index >= 0 && record.changeIds[index] == buffer.GetUndoChangeId())
			{
				var numBuffersInSync = 0;
				var numBuffers = record.guids.Count;
				for (var j = numBuffers; j --> 0; )
				{
					var guid = record.guids[j];
					var otherBuffer = _instance.allBuffers.Find(x => x != null && guid == x.guid);
					if (otherBuffer != null && otherBuffer.GetUndoChangeId() == record.changeIds[j])
						++numBuffersInSync;
				}
				
				var focus = EditorWindow.focusedWindow;
				bool globalUndo = false;
				
				if (numBuffers == numBuffersInSync)
				{
					globalUndo = EditorUtility.DisplayDialog("Si3 - Global Undo", "You are about to Undo an operation that has affected " + numBuffers.ToString() + " files!\n\n" +
						"- Select 'Global Undo' to undo all related changes.\n" +
						"- Select 'Local Undo' to undo changes in the current file only.",
						"Global Undo",
						"Local Undo");
				}
				else if (numBuffersInSync >= 2)
				{
					globalUndo = EditorUtility.DisplayDialog("Si3 - Global Undo", "You are about to Undo an operation that has affected " + numBuffers.ToString() + " files!\n\n" +
						"However, Global Undo is only available for " + numBuffersInSync + " files at this time...\n\n" +
						"- Select 'Global Undo' to undo related changes in those files only.\n" +
						"- Select 'Local Undo' to undo changes in the current file only.",
						"Global Undo",
						"Local Undo");
				}
				else
				{
					EditorUtility.DisplayDialog("Si3 - Global Undo", "You are about to Undo an operation that has affected " + numBuffers.ToString() + " files!\n\n" +
						"However, Global Undo is not available for any other file at this time\n" +
						"and only the current file will be affected...",
						"Local Undo");
				}
				
				if (globalUndo)
				{
					for (var j = numBuffers; j --> 0; )
					{
						var guid = record.guids[j];
						var otherBuffer = _instance.allBuffers.Find(x => x != null && guid == x.guid);
						if (otherBuffer != null && otherBuffer.GetUndoChangeId() == record.changeIds[j])
							otherBuffer.Undo();
					}
				}
				
				if (focus)
					focus.Focus();
				return globalUndo;
			}
		}
		
		return false;
	}
	
	public static bool GlobalRedo(FGTextBuffer buffer)
	{
		var globalUndoRecords = Instance().globalUndoRecords;
		if (globalUndoRecords.Count == 0)
			return false;
		
		for (var i = globalUndoRecords.Count; i --> 0; )
		{
			var record = globalUndoRecords[i];
			var index = record.guids.IndexOf(buffer.guid);
			if (index >= 0 && record.changeIds[index] == buffer.GetRedoChangeId())
			{
				var numBuffersInSync = 0;
				var numBuffers = record.guids.Count;
				for (var j = numBuffers; j --> 0; )
				{
					var guid = record.guids[j];
					var otherBuffer = _instance.allBuffers.Find(x => x != null && guid == x.guid);
					if (otherBuffer != null && otherBuffer.GetRedoChangeId() == record.changeIds[j])
						++numBuffersInSync;
				}
				
				var focus = EditorWindow.focusedWindow;
				bool globalRedo = false;
				
				if (numBuffers == numBuffersInSync)
				{
					globalRedo = EditorUtility.DisplayDialog("Si3 - Global Redo", "You are about to Redo an operation that has affected " + numBuffers.ToString() + " files!\n\n" +
						"- Select 'Global Redo' to redo all related changes.\n" +
						"- Select 'Local Redo' to redo changes in the current file only.",
						"Global Redo",
						"Local Redo");
				}
				else if (numBuffersInSync >= 2)
				{
					globalRedo = EditorUtility.DisplayDialog("Si3 - Global Redo", "You are about to Redo an operation that has affected " + numBuffers.ToString() + " files!\n\n" +
						"However, Global Redo is only available for " + numBuffersInSync + " files at this time...\n\n" +
						"- Select 'Global Redo' to redo related changes in those files only.\n" +
						"- Select 'Local Redo' to redo changes in the current file only.",
						"Global Redo",
						"Local Redo");
				}
				else
				{
					EditorUtility.DisplayDialog("Si3 - Global Redo", "You are about to Redo an operation that has affected " + numBuffers.ToString() + " files!\n\n" +
						"However, Global Redo is not available for any other file at this time\n" +
						"and only the current file will be affected...",
						"Local Redo");
				}
				
				if (globalRedo)
				{
					for (var j = numBuffers; j --> 0; )
					{
						var guid = record.guids[j];
						var otherBuffer = _instance.allBuffers.Find(x => x != null && guid == x.guid);
						if (otherBuffer != null && otherBuffer.GetRedoChangeId() == record.changeIds[j])
							otherBuffer.Redo();
					}
				}
				
				if (focus)
					focus.Focus();
				return globalRedo;
			}
		}
		
		return false;
	}
	
	public static void AddRecentLocation(string assetGuid, FGTextBuffer.CaretPos caretPosition, bool insert)
	{
		if (_instance == null)
			return;
		
		var newLocation = new RecentLocation {
			assetGuid = assetGuid,
			line = caretPosition.line,
			index = caretPosition.characterIndex
		};
		
		if (insert && _instance.recentLocationsOffset != 0)
		{
			var current = _instance.recentLocations.Count - _instance.recentLocationsOffset;
			_instance.recentLocations.Insert(current, newLocation);
		}
		else
		{
			if (_instance.recentLocationsOffset != 0)
			{
				var current = _instance.recentLocations.Count - _instance.recentLocationsOffset;
				_instance.recentLocations.RemoveRange(current, _instance.recentLocationsOffset);
			}
			_instance.recentLocations.Add(newLocation);
			_instance.recentLocationsOffset = 0;
		}
		
		if (_instance.recentLocations.Count > 100 + _instance.recentLocationsOffset)
		{
			_instance.recentLocations.RemoveRange(0, _instance.recentLocations.Count - 100 - _instance.recentLocationsOffset);
		}
	}
	
	public static void OnInsertedText(FGTextBuffer buffer, TextPosition from, TextPosition to)
	{
		var guid = buffer.guid;

		var recentLocations = Instance().recentLocations;
		for (var i = recentLocations.Count; i --> 0; )
		{
			var entry = recentLocations[i];
			
			var location = new TextPosition(entry.line, entry.index);
			if (location.OnInsertedText(from, to, !insertingTextAfterCaret))
			{
				if (entry.assetGuid != guid)
					continue;
			
				entry.line = location.line;
				entry.index = location.index;
			}
		}
	}
	
	public static void OnRemovedText(FGTextBuffer buffer, TextPosition from, TextPosition to)
	{
		var guid = buffer.guid;
		
		var recentLocations = Instance().recentLocations;
		for (var i = recentLocations.Count; i --> 0; )
		{
			var entry = recentLocations[i];
			if (entry.assetGuid != guid)
				continue;
			
			var location = new TextPosition(entry.line, entry.index);
			if (from >= location)
				continue;
			
			if (to >= location)
			{
				entry.line = from.line;
				entry.index = from.index;
				continue;
			}
			
			if (to.line == location.line)
				entry.index -= to.index - from.index;
			entry.line -= to.line - from.line;
		}
		
		if (recentLocations.Count > 1)
		{
			var prevLocation = recentLocations[0];
			for (var i = 1; i < recentLocations.Count; ++i)
			{
				var entry = recentLocations[i];
				if (entry.assetGuid != prevLocation.assetGuid || entry.line != prevLocation.line || entry.index != prevLocation.index)
				{
					prevLocation = entry;
				}
				else
				{
					if (_instance.recentLocationsOffset >= recentLocations.Count - i)
						--_instance.recentLocationsOffset;
					recentLocations.RemoveAt(i);
					--i;
				}
			}
		}
	}
	
	public static void AddPendingAssetImport(string guid)
	{
		pendingAssetImports.Add(guid);
	}
	
	public static bool HasPendingAssetImports
	{
		get { return pendingAssetImports.Count > 0; }
	}
	
	public static void ImportPendingAssets()
	{
		List<string> failedImports = null;
		AssetDatabase.StartAssetEditing();
		foreach (var guid in pendingAssetImports)
		{
			try
			{
				AssetDatabase.ImportAsset(AssetDatabase.GUIDToAssetPath(guid));
			}
			catch
			{
				if (failedImports == null)
					failedImports = new List<string>();
				failedImports.Add(guid);
			}
		}

		AssetDatabase.StopAssetEditing();
		pendingAssetImports.Clear();
		
		if (failedImports != null)
			foreach (var guid in failedImports)
				pendingAssetImports.Add(guid);
	}

	public static bool SaveAllModified(bool onQuit)
	{
		var focusedWindow = EditorWindow.focusedWindow;
		
		if (_instance == null)
			return false;
		
		//bool locked = false;
		try
		{
			foreach (FGTextBuffer buffer in Instance().allBuffers)
			{
				if (buffer == null)
					continue;

				if (buffer.IsModified)
				{
					string path = AssetDatabase.GUIDToAssetPath(buffer.guid);
					if (onQuit && !EditorUtility.DisplayDialog("Script Inspector", "Save changes to the following asset?\n\n" + path, "Save", "Don't Save"))
						continue;

					//if (!onQuit && !locked)
					//{
					//	EditorApplication.LockReloadAssemblies();
					//	locked = true;
					//}
		
					if (buffer.Save())
					{
						if (!onQuit)
						{
							AssetDatabase.ImportAsset(path);
							//var asset = AssetDatabase.LoadAssetAtPath(path, typeof(MonoScript));
							//if (asset != null)
							//	EditorUtility.SetDirty(asset);
							buffer.UpdateViews();
						}
					}
				}
			}
			
			if (!onQuit && focusedWindow)
				focusedWindow.Focus();
			
			if (pendingAssetImports.Count == 0)
				return false;
			
			if (!onQuit)
			{
				ImportPendingAssets();
				if (focusedWindow)
					focusedWindow.Focus();
			}
		}
		catch (Exception e)
		{
			Debug.LogError(e);
		}
		//finally
		//{
		//	if (locked)
		//	{
		//		EditorApplication.UnlockReloadAssemblies();
		//	}
		//}
		return true;
	}

	private static FGTextBufferManager _instance = null;
	public static FGTextBufferManager Instance()
	{
		if (_instance == null)
		{
			var allInstances = Resources.FindObjectsOfTypeAll(typeof(FGTextBufferManager)) as FGTextBufferManager[];
			if (allInstances.Length > 0)
			{
				_instance = allInstances[0];
				//Debug.LogWarning("Found existing instances - " + allInstances.Length);
			}
			else
			{
				_instance = ScriptableObject.CreateInstance<FGTextBufferManager>();
				//Debug.LogWarning("Created a new instance!");
			}
			_instance.hideFlags = HideFlags.HideAndDontSave;
		}
		return _instance;
	}
	
	public static FGTextBuffer TryGetBuffer(string assetPath)
	{
		if (!assetPath.StartsWithIgnoreCase("assets/") && !assetPath.StartsWithIgnoreCase("packages/"))
			return null;
		
		string guid = AssetDatabase.AssetPathToGUID(assetPath);
		return Instance().allBuffers.Find(x => x != null && guid == x.guid);
	}

	public static FGTextBuffer GetBuffer(UnityEngine.Object target)
	{
		string guid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(target));
		return GetBuffer(guid);
	}
	
	public static FGTextBuffer GetBuffer(string guid)
	{
		//Debug.Log("GetBuffer " + AssetDatabase.GUIDToAssetPath(guid));
		
		List<FGTextBuffer> buffers = Instance().allBuffers.FindAll(x => x != null && guid == x.guid);
		if (buffers.Count > 0)
		{
			if (buffers.Count > 1)
			{
				Debug.Log("Removing " + (buffers.Count - 1) + " duplicates...");
				for (int i = 1; i < buffers.Count; ++i)
					Instance().allBuffers.Remove(buffers[i]);
			}
			
			return buffers[0];
		}
		//Debug.Log("... not found ...");

		FGTextBuffer buffer = CreateInstance<FGTextBuffer>();
		buffer.guid = guid;
		Instance().allBuffers.Add(buffer);
		
		//Debug.Log("    Count " + _instance.allBuffers.Count);
		//foreach (var debug in _instance.allBuffers)
		//{
		//	Debug.Log("    " + AssetDatabase.GUIDToAssetPath(debug.guid) + " " + debug.undoPosition + " " + debug.guid);
		//}
		
		return buffer;
	}

	public static void DestroyBuffer(FGTextBuffer buffer)
	{
		Instance().allBuffers.Remove(buffer);
		DestroyImmediate(buffer);
	}
	
	private static Dictionary<AssemblyDefinition, List<string>> scriptsWithPartialClass;
	private static Dictionary<AssemblyDefinition, List<string>> scriptsWithPartialStruct;
	private static Dictionary<AssemblyDefinition, List<string>> scriptsWithPartialInterface;
	
	public static void FindOtherTypeDeclarationParts(SymbolDeclaration declaration)
	{
		if (scriptsWithPartialClass == null)
		{
			scriptsWithPartialClass = new Dictionary<AssemblyDefinition, List<string>>();
			scriptsWithPartialStruct = new Dictionary<AssemblyDefinition, List<string>>();
			scriptsWithPartialInterface = new Dictionary<AssemblyDefinition, List<string>>();
		}
		
		var typeDefinition = declaration.definition as TypeDefinition;
		if (typeDefinition == null)
			return;
		var assembly = typeDefinition.Assembly;
		
		var cachedAssemblyScripts =
			declaration.kind == SymbolKind.Class ? scriptsWithPartialClass :
			declaration.kind == SymbolKind.Struct ? scriptsWithPartialStruct :
			scriptsWithPartialInterface;
		List<string> scriptsWithPartials;
		if (!cachedAssemblyScripts.TryGetValue(assembly, out scriptsWithPartials))
		{
			FGFindInFiles.Reset();
			FGFindInFiles.FindAllAssemblyScripts(assembly);
			
			cachedAssemblyScripts[assembly] = scriptsWithPartials = new List<string>(FGFindInFiles.assets.Count);
			
			var partialTypePhrase = new string[] {
				"partial",
				declaration.kind == SymbolKind.Class ? "class" : declaration.kind == SymbolKind.Struct ? "struct" : "interface"
			};
			for (var i = FGFindInFiles.assets.Count; i --> 0; )
			{
				var assetPath = AssetDatabase.GUIDToAssetPath(FGFindInFiles.assets[i]);
				if (FGFindInFiles.ContainsWordsSequence(assetPath, partialTypePhrase))
					scriptsWithPartials.Add(FGFindInFiles.assets[i]);
			}
		}
		
		var words = new string[] {
			"partial",
			declaration.kind == SymbolKind.Class ? "class" : declaration.kind == SymbolKind.Struct ? "struct" : "interface",
			declaration.Name
		};
		for (var i = scriptsWithPartials.Count; i --> 0; )
		{
			var assetPath = AssetDatabase.GUIDToAssetPath(scriptsWithPartials[i]);
			if (FGFindInFiles.ContainsWordsSequence(assetPath, words))
			{
				asyncParseBuffers.Enqueue(scriptsWithPartials[i]);
				scriptsWithPartials.RemoveAt(i);
			}
		}
	}
	
	private static bool parsingAllAsyncBuffers = false;
	public static void ParseAllAsyncBuffers()
	{
		if (parsingAllAsyncBuffers)
			return;
		
		parsingAllAsyncBuffers = true;
		try
		{
			while (asyncParseBuffers.Count > 0)
				ParseNextAsyncBuffer();
		}
		finally
		{
			parsingAllAsyncBuffers = false;
		}
	}
	
	private static void ParseNextAsyncBuffer()
	{
		if (asyncParseBuffers.Count > 0)
		{
			var guid = asyncParseBuffers.Dequeue();
			var buffer = GetBuffer(guid);
			if (buffer.Parser == null)
				buffer.LoadImmediately();
		}
	}
	
	public static bool isApplicationActive = true;
	
	private static void OnUpdate()
	{
		var isFocused = UnityEditorInternal.InternalEditorUtility.isApplicationActive;
		if (isFocused != isApplicationActive)
		{
			isApplicationActive = isFocused;
			if (isFocused)
			{
				//Debug.Log("Early EditorApplication.isUpdating: " + EditorApplication.isUpdating);
				EditorApplication.delayCall += OnApplicationFocused;
			}
			else
			{
				OnApplicationLostFocus();
			}
		}

		ParseNextAsyncBuffer();
	}
	
	static void OnApplicationLostFocus()
	{
	}
	
	static void CheckForNewVersion()
	{
		var lastKnownVersion = EditorPrefs.GetString(OptionsBase.prefix + "LastKnownVersion." +
			ScriptInspector.ScriptInspector.GetVersion(), "");
		var versionCheckedDay = EditorPrefs.GetInt(OptionsBase.prefix + "VersionCheckedDay." +
			ScriptInspector.ScriptInspector.GetVersion(), 0);
		var nowDay = System.DateTime.Now.Day;
		if (versionCheckedDay != nowDay || lastKnownVersion == "")
		{
			CheckVersion();
		}
		else
		{
			versionInfo.version = lastKnownVersion;
			versionInfo.name = "Script Inspector 3";
		}
	}
	
	public class PackageVersionInfo
	{
		public string version;
		public string name;
		
		public override string ToString()
		{
			return name + " version " + version;
		}
	}
	
	static public bool IsUpdateAvailable()
	{
		if (string.IsNullOrEmpty(versionInfo.version))
			return false;
		
		return versionInfo.version != ScriptInspector.ScriptInspector.GetVersion();
	}
	
	static public PackageVersionInfo versionInfo = new PackageVersionInfo() { version = "", name = "" };
	
	static void CheckVersion()
	{
		const string url = "https://api.assetstore.unity3d.com/package/latest-version/3535";
		var www = UnityEngine.Networking.UnityWebRequest.Get(url);
		var request = www.SendWebRequest();
		request.completed += r =>
		{
			var webRequest = ((UnityEngine.Networking.UnityWebRequestAsyncOperation)r).webRequest;

#if UNITY_2020_1_OR_NEWER
			if (webRequest.result != UnityEngine.Networking.UnityWebRequest.Result.Success)
#else
			if (webRequest.isNetworkError || webRequest.isHttpError)
#endif
			{
				webRequest.Dispose();
				return;
			}

			var text = webRequest.downloadHandler.text;
			webRequest.Dispose();

			versionInfo.version = "";
			versionInfo.name = "";
			EditorJsonUtility.FromJsonOverwrite(text, versionInfo);

			var day = System.DateTime.Now.Day;
			EditorPrefs.SetInt(OptionsBase.prefix + "VersionCheckedDay." +
				ScriptInspector.ScriptInspector.GetVersion(), day);
			
			EditorPrefs.SetString(OptionsBase.prefix + "LastKnownVersion." +
				ScriptInspector.ScriptInspector.GetVersion(), versionInfo.version);

			if (versionInfo.version != "" && ScriptInspector.ScriptInspector.GetVersion() != versionInfo.version)
				Debug.LogWarning("An update for " + versionInfo.name + " is available - new version " + versionInfo.version);
		};
	}
	
	static void OnApplicationFocused()
	{
		//var autoRefresh = EditorPrefs.GetInt("kAutoRefresh");
		//Debug.Log("autoRefresh: " + autoRefresh);
		
//#if UNITY_2021_3_OR_NEWER
//		var autoRefreshMode = EditorPrefs.GetInt("kAutoRefreshMode");
//		Debug.Log("autoRefreshMode: " + autoRefreshMode);
//#endif
        
		//Debug.Log("EditorApplication.isUpdating: " + EditorApplication.isUpdating);
		
		Instance().CheckExternallyModifiedBuffers();
	}

	private void CheckExternallyModifiedBuffers()
	{
		var defaultTime = new System.DateTime();
		for (int i = allBuffers.Count; i --> 0; )
		{
			var buffer = allBuffers[i];
			if (buffer.lastModifiedTime == defaultTime)
				continue;
			
			if (string.IsNullOrEmpty(buffer.assetPath))
				continue;
			
			var fileTime = System.IO.File.GetLastWriteTime(buffer.assetPath).ToUniversalTime();
			if (fileTime <= buffer.lastModifiedTime)
				continue;
			
			Debug.LogWarning("Si3 will reload externally modified file: " + buffer.assetPath);
			//OnAssetReimported(buffer.assetPath);
			buffer.Reload();
		}
	}

	public class FGScriptPostprocessor : AssetPostprocessor
	{
		static void OnPostprocessAllAssets(string[] importedAssets, string[] deletedAssets, string[] movedAssets, string[] movedFromAssetPaths)
		{
			if (_instance == null)
				return;

			foreach (string imported in importedAssets)
			{
				if (imported.EndsWithJS() ||
					imported.EndsWithCS() ||
					imported.EndsWithBoo())
				{
					if (!Array.Exists(movedAssets, (string path) => imported == path))
					{
						Instance().OnAssetReimported(imported);
					}

					reloadingAssemblies = true;
				}
				else
				{
					Instance().OnAssetReimported(imported);
				}
			}

			//foreach (string str in deletedAssets)
			//    Debug.Log("== Deleted Asset: " + str);

			for (int i = 0; i < movedAssets.Length; ++i)
			{
				if (movedAssets[i].EndsWithJS() ||
					movedAssets[i].EndsWithCS() ||
					movedAssets[i].EndsWithBoo())
				{
					Instance().OnAssetMoved(movedAssets[i]);
				}
			}
			
			if (reloadingAssemblies)
			{
				EditorApplication.update -= CompileErrorsCheck;
				EditorApplication.update += CompileErrorsCheck;
				
				if (SISettings.autoFocusConsole == 2)
				{
					var focusedWindow = EditorWindow.focusedWindow;
					var siConsole = FGConsole.FindInstance();
					if (siConsole)
					{
						siConsole.Focus();
						if (focusedWindow)
							focusedWindow.Focus();
					}
				}
			}
			
			EditorApplication.update -= RepaintConsoleAfterUpdate;
			EditorApplication.update += RepaintConsoleAfterUpdate;
		}
	}

	private static void CompileErrorsCheck()
	{
		if (EditorApplication.isCompiling)
			return;

		EditorApplication.update -= CompileErrorsCheck;
		reloadingAssemblies = false;
		//EditorUtility.DisplayDialog("Script Inspector", "Compile errors!", "OK");
		FGTextEditor.RepaintAllInstances();
		FGConsole.repaintOnUpdateCounter = 1;
		
		if (SISettings.autoFocusConsole != 0)
		{
			FGConsole.ShowConsole();
			var siConsole = FGConsole.FindInstance();
			if (siConsole)
				siConsole.SendEvent(Event.KeyboardEvent("%end"));
		}
	}
	
	private static void RepaintConsoleAfterUpdate()
	{
		if (EditorApplication.isUpdating)
			return;

		EditorApplication.update -= RepaintConsoleAfterUpdate;
		FGConsole.repaintOnUpdateCounter = 1;
	}
	
	public void OnAssetReimported(string assetPath)
	{
		if (!assetPath.StartsWithIgnoreCase("assets/") && !assetPath.StartsWithIgnoreCase("packages/"))
		{
			return;
		}
		
		string guid = AssetDatabase.AssetPathToGUID(assetPath);
		FGTextBuffer buffer = allBuffers.Find((FGTextBuffer x) => guid == x.guid);
		if (buffer != null)
		{
			buffer.Reload();
		}
	}

	public void OnAssetMoved(string assetPath)
	{
		if (!assetPath.StartsWithIgnoreCase("assets/") && !assetPath.StartsWithIgnoreCase("packages/"))
			return;
		
		string guid = AssetDatabase.AssetPathToGUID(assetPath);
		FGTextBuffer buffer = allBuffers.Find(x => guid == x.guid);
		if (buffer != null)
		{
			buffer.justSavedNow = true;
		}
	}
}
