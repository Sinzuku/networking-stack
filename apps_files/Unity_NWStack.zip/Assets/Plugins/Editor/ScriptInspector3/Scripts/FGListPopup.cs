﻿/* SCRIPT INSPECTOR 3
 * version 3.1.11, December 2024
 * Copyright © 2012-2024, Flipbook Games
 *
 * Script Inspector 3 - World's Fastest IDE for Unity
 *
 *
 * Follow me on http://twitter.com/FlipbookGames
 * Like Flipbook Games on Facebook http://facebook.com/FlipbookGames
 * Join discussion in Unity forums http://forum.unity3d.com/threads/138329
 * Contact info@flipbookgames.com for feedback, bug reports, or suggestions.
 * Visit http://flipbookgames.com/ for more info.
 */

namespace ScriptInspector
{

using System;
using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;


public class FGListPopup : FGPopupWindow
{
	private static int currentItem = -1;
	private static SymbolDefinition[] data;
	private static List<SymbolDefinition> filteredData = new List<SymbolDefinition>();
	private static List<SymbolDefinition> newFilteredData = new List<SymbolDefinition>();
	private static BacktrackingStringMatcher matcher;
	
	private Rect scrollViewRect;
	private static int scrollPosition;
	private const int maxListItems = 9;
	private static float listItemHeight = 19f;
	private bool isSizeSet;
	private float currentWidth;

	public static CharSpan NameOf(SymbolDefinition symbol)
	{
		var name = symbol.name;
		
		if (shortAttributeNames && symbol.kind == SymbolKind.Class &&
			symbol.name.FastEndsWith("Attribute") && symbol.name != "Attribute")
		{
			name = name.Substring(0, name.length - "Attribute".Length);
		}
		
		return name;
	}
	
	private static string ItemDisplayString(SymbolDefinition symbol, string styledName)
	{
		return " " + symbol.CompletionDisplayString(styledName);
	}
	
	private static string topSuggestion;

	private static char[] commaOnlyCharArray = { ',' };
	private static List<string> _recentCompletions;
	private static List<string> recentCompletions
	{
		get {
			if (_recentCompletions == null)
			{
				_recentCompletions = new List<string>(200);
				savedRecentCompletions = new List<string>(200);
				var s = EditorPrefs.GetString("ScriptInspectorRecentCompletions_1", "");
				_recentCompletions.AddRange(s.Split(commaOnlyCharArray, StringSplitOptions.RemoveEmptyEntries));
				savedRecentCompletions.AddRange(_recentCompletions);
			}
			return _recentCompletions;
		}
	}
	
	private static List<string> savedRecentCompletions;

	private static FGTextBuffer textBuffer;
	private static FGTextEditor textEditor;
	private bool completeOnUpdate;

	private static int startAtCharacterIndex;
	private static int lineIndex;

	public static SyntaxToken tokenLeft;
	
	public static bool shortAttributeNames;

	class SymbolDefinitionComparer : IComparer<SymbolDefinition>
	{
		public int Compare(SymbolDefinition a, SymbolDefinition b)
		{
			var nameOfA = NameOf(a);
			var nameOfB = NameOf(b);
			var c = nameOfA.CompareToIgnoreCase(nameOfB);
			if (c == 0)
				c = nameOfA.CompareTo(nameOfB);
			return c;
		}
	}

	private static readonly SymbolDefinitionComparer symbolDefinitionComparer = new SymbolDefinitionComparer();
	
	public static bool IdentifiersOnly { get; private set; }
	
	[NonSerialized]
	public static bool defensiveMode;
	
	private static HashSet<string> bestMatches = new HashSet<string>();

	private static string typedInPart = "";
	public static string TypedInPart
	{
		get { return typedInPart; }
		set
		{
			matcher = null;
			if (data == null)
				return;
			
			bool hadSelection = currentItem >= 0;
			bool fullNameMatch = false;
			
			value = SymbolDefinition.DecodeId(value).GetString();

			var focusRecent = false;
			bestMatches.Clear();
			var tempSymbol = new SymbolDefinition { name = value };

			var filteredIndex = currentItem < 0 ? ~currentItem : currentItem;
			var focused = filteredData.Count > 0 && filteredIndex < filteredData.Count ? filteredData[filteredIndex] : null;

			typedInPart = value;
			if (value == "")
			{
				filteredData.Clear();
				filteredData.AddRange(data);
				if (focused != null)
				{
					filteredIndex = filteredData.IndexOf(focused);
					currentItem = currentItem < 0 ? ~filteredIndex : filteredIndex;
					focusRecent = topSuggestion != null;
				}
				else
				{
					currentItem = -1;
					focusRecent = true;
				}
			}
			else
			{
				matcher = new BacktrackingStringMatcher(value);
				bestMatches.Clear();
				var bestMatch = -1;
				var bestRank = -1;
				newFilteredData.Clear();
				for (var i = 0; i < data.Length; ++i)
				{
					var name = NameOf(data[i]);
					int rank;
					if (!matcher.CalcMatchRank(name, out rank))
						continue;
					if (rank > bestRank)
					{
						bestMatch = newFilteredData.Count;
						bestRank = rank;
						bestMatches.Clear();
						bestMatches.Add(name);
						if (rank >= int.MaxValue - value.Length - 1)
						{
							fullNameMatch = true;
							focused = null;
						}
					}
					else if (rank == bestRank && bestMatches.Count <= 1)
						bestMatches.Add(name);
					newFilteredData.Add(data[i]);
				}

				if (newFilteredData.Count == 0)
				{
					if (currentItem >= 0)
						currentItem = ~currentItem;
				}
				else
				{
					var swapTemp = filteredData;
					filteredData = newFilteredData;
					newFilteredData = swapTemp;
					
					if (focused != null)
					{
						if (focused.name.StartsWithIgnoreCase(value))
						{
							currentItem = filteredData.IndexOf(focused);
						}
						else
						{
							currentItem = bestMatch;
							if (bestMatches.Count > 1)
								focusRecent = true;
						}
					}
					else
					{
						currentItem = bestMatch;
						focusRecent = !fullNameMatch &&
							(filteredData.Count > 1 || currentItem < 0 || topSuggestion != null);
					}
				}
			}
			
			//if (currentItem >= 0)
			//{
			//	Debug.Log("\"" + typedInPart + "\" " + filteredData[currentItem].name + " " + focusRecent + " " + topSuggestion);
			//}
			
			if (focusRecent && (!hadSelection || currentItem < 0 || value != filteredData[currentItem].name))
			{
				if (topSuggestion != null && !fullNameMatch)
				{
					tempSymbol.name = topSuggestion;
					var suggestedItemIndex = filteredData.BinarySearch(tempSymbol, symbolDefinitionComparer);
					if (suggestedItemIndex >= 0)
					{
						currentItem = suggestedItemIndex;
						focusRecent = false;
					}
				}
				
				if (focusRecent)
				{
					for (var i = recentCompletions.Count; i --> 0; )
					{
						tempSymbol.name = recentCompletions[i];
						var recentItemIndex = filteredData.BinarySearch(tempSymbol, symbolDefinitionComparer);
						if (recentItemIndex >= 0 &&
							(value == "" || value[0] == '@' || value[0] == '_' || char.IsLower(value[0]) || !char.IsLower(tempSymbol.name[0])))
						{
							if (filteredData[recentItemIndex].name.StartsWithIgnoreCase(filteredData[currentItem >= 0 ? currentItem : ~currentItem].name))
								break;
							
							//Debug.Log((currentItem >= 0 ? filteredData[currentItem].name : "...") + " -> " +
							//	filteredData[recentItemIndex].name + " " + recentItemIndex);
							
							currentItem = recentItemIndex;
							break;
						}
					}
				}
			}
			
			if (currentItem > 0 && currentItem < filteredData.Count)
			{
				var currentItemName = filteredData[currentItem].name;
				if (topSuggestion == null || topSuggestion != currentItemName)
				{
					var exactMatchItemIndex = currentItem;
					while (exactMatchItemIndex > 0)
					{
						--exactMatchItemIndex;
						var exactMatchItemName = filteredData[exactMatchItemIndex].name;
						if (currentItemName.FastStartsWith(exactMatchItemName) && exactMatchItemName.length < currentItemName.length)
						{
							currentItem = exactMatchItemIndex;
							currentItemName = exactMatchItemName;
						}
						if (char.ToLower(currentItemName[0]) != char.ToLower(exactMatchItemName[0]))
						{
							break;
						}
					}
				}
			}

			if (!hadSelection && currentItem >= 0 && (defensiveMode || !SISettings.autoCompleteAggressively))
				currentItem = ~currentItem;
			CenterScrollCurrentItem();
		}
	}

	public static void UpdateTypedInPart()
	{
		var caretPosition = textEditor.caretPosition;
		var line = textBuffer.lines[caretPosition.line];

		var charIndex = caretPosition.characterIndex;
		while (charIndex > 0)
		{
			if (!char.IsLetterOrDigit(line, charIndex - 1) &&
				line[charIndex - 1] != '_' &&
				line[charIndex - 1] != '\\')
			{
				if (line[charIndex - 1] == '@')
				{
					IdentifiersOnly = true;
					--charIndex;
				}
				break;
			}
			--charIndex;
		}
		if (startAtCharacterIndex < charIndex)
		{
			typedInPart = "";
			return;
		}
		if (startAtCharacterIndex > caretPosition.characterIndex)
		{
			typedInPart = "";
			return;
		}

		var wordAtLeft = line.Substring(charIndex, caretPosition.characterIndex - charIndex);
		TypedInPart = wordAtLeft;
	}

	private static GUIStyle listItemStyle;
	private static Texture2D[,] symbolIcons;
	private static Texture2D keywordIcon;
	private static Texture2D inactiveListItem;
	private static Texture2D selectedListItem;

	private static void LoadSymbolIcons()
	{
		SymbolKind[] kinds = { SymbolKind.Namespace, SymbolKind.Interface, SymbolKind.Enum, SymbolKind.Struct,
			SymbolKind.Class, SymbolKind.Delegate, SymbolKind.Field, SymbolKind.ConstantField, SymbolKind.LocalConstant,
			SymbolKind.EnumMember, SymbolKind.Property, SymbolKind.Event, SymbolKind.Indexer,
			SymbolKind.Method, SymbolKind.Constructor, SymbolKind.Destructor, SymbolKind.Operator,
			SymbolKind.Accessor, SymbolKind.Parameter, SymbolKind.CatchParameter, SymbolKind.Variable,
			SymbolKind.CaseVariable, SymbolKind.TupleDeconstructVariable,
			SymbolKind.OutVariable, SymbolKind.IsVariable, SymbolKind.ForEachVariable, SymbolKind.FromClauseVariable,
			SymbolKind.TypeParameter, SymbolKind.Label };
		var oneForAll = new HashSet<SymbolKind> { SymbolKind.Namespace, SymbolKind.EnumMember, SymbolKind.Parameter,
			SymbolKind.CatchParameter, SymbolKind.Variable, SymbolKind.CaseVariable, SymbolKind.OutVariable,
			SymbolKind.IsVariable, SymbolKind.ForEachVariable, SymbolKind.FromClauseVariable,
			SymbolKind.TupleDeconstructVariable, SymbolKind.TypeParameter, SymbolKind.Label, SymbolKind.LocalConstant,
			SymbolKind.Constructor, SymbolKind.Destructor };
		symbolIcons = new Texture2D[System.Enum.GetNames(typeof(SymbolKind)).Length, 3];
		for (var i = 0; i < kinds.Length; i++)
		{
			var kind = kinds[i].ToString();
			if (kind == "ConstantField" || kind == "LocalConstant")
				kind = "Constant";
			else if (kind == "EnumMember")
				kind = "EnumItem";
			else if (kind == "CaseVariable")
				kind = "Variable";
			else if (kind == "TupleDeconstructVariable")
				kind = "Variable";
			else if (kind == "OutVariable")
				kind = "Variable";
			else if (kind == "IsVariable")
				kind = "Variable";
			var index = (int) kinds[i];
			symbolIcons[index, 0] = FGTextEditor.LoadEditorResource<Texture2D>("Symbol Icons/VSObject_" + kind + ".png");
			if (oneForAll.Contains(kinds[i]))
			{
				symbolIcons[index, 1] = symbolIcons[index, 0];
				symbolIcons[index, 2] = symbolIcons[index, 0];
			}
			else
			{
				symbolIcons[index, 1] = FGTextEditor.LoadEditorResource<Texture2D>("Symbol Icons/VSObject_" + kind + "_Protected.png");
				symbolIcons[index, 2] = FGTextEditor.LoadEditorResource<Texture2D>("Symbol Icons/VSObject_" + kind + "_Private.png");
			}
			
#if SI3_WARNINGS
			if (symbolIcons[index, 0] == null)
				Debug.LogWarning("No icon for " + kind + " - " + kinds[i].ToString());
			if (symbolIcons[index, 1] == null)
				Debug.LogWarning("No icon for protected " + kind + " - " + kinds[i].ToString());
			if (symbolIcons[index, 2] == null)
				Debug.LogWarning("No icon for private " + kind + " - " + kinds[i].ToString());
#endif
		}
		symbolIcons[(int) SymbolKind._Keyword, 0] = keywordIcon = FGTextEditor.LoadEditorResource<Texture2D>("Symbol Icons/Keyword.png");
		symbolIcons[(int) SymbolKind._Keyword, 1] = keywordIcon;
		symbolIcons[(int) SymbolKind._Keyword, 2] = keywordIcon;
		var snippetIcon = FGTextEditor.LoadEditorResource<Texture2D>("Symbol Icons/Snippet.png");
		symbolIcons[(int) SymbolKind._Snippet, 0] = snippetIcon;
		symbolIcons[(int) SymbolKind._Snippet, 1] = snippetIcon;
		symbolIcons[(int) SymbolKind._Snippet, 2] = snippetIcon;

		inactiveListItem = FGTextEditor.LoadEditorResource<Texture2D>("inactiveListItem.png");
		selectedListItem = FGTextEditor.LoadEditorResource<Texture2D>("selectedListItem.png");
	}
	
	private static void LoadResources()
	{
		if (symbolIcons == null)
			LoadSymbolIcons();
		
		var textColor = FGTextEditor.StylesCode.normalStyle.normal.textColor;
		
		var hollowTexture = new Texture2D(1, 1);
		hollowTexture.SetPixel(0, 0, Color.clear);
		hollowTexture.Apply();
		
		listItemStyle = new GUIStyle
		{
			fixedHeight = 0,
			padding = { left = 2, top = 2, bottom = 4, right = 2 },
			border = new RectOffset(2, 2, 2, 2),
			margin = new RectOffset(3, 3, 0, 0),
			overflow = { left = -20 },

			normal = { background = hollowTexture, textColor = textColor },
			onFocused = { background = selectedListItem },
			onNormal = { background = inactiveListItem, textColor = textColor },
		};
	}
	
	public static bool Init(FGTextEditor editor)
	{
		if (editor == null)
			return false;

		scrollPosition = 0;
		currentItem = -1;
		data = null;
		if (filteredData == null)
			filteredData = new List<SymbolDefinition>();
		else
			filteredData.Clear();
		if (newFilteredData == null)
			newFilteredData = new List<SymbolDefinition>();
		else
			newFilteredData.Clear();
		matcher = null;

		topSuggestion = null;
		defensiveMode = false;

		textEditor = editor;
		textBuffer = editor.TextBuffer;

		typedInPart = "";
		int tokenIndex;
		bool atTokenEnd;
		var onToken = editor.TextBuffer.GetTokenAt(editor.caretPosition, out lineIndex, out tokenIndex, out atTokenEnd);
		if (onToken != null && /*!atTokenEnd &&*/ onToken.tokenKind >= SyntaxToken.Kind.Keyword)
		{
			// eat
			var textSpan = editor.TextBuffer.GetTokenSpan(lineIndex, tokenIndex);
			startAtCharacterIndex = textSpan.StartPosition.index;
			
			tokenLeft = editor.TextBuffer.GetNonTriviaTokenLeftOf(lineIndex, startAtCharacterIndex);

			typedInPart = onToken.text.Substring(0, editor.caretPosition.characterIndex - textSpan.index).GetString();
			//	Debug.Log("typedInPart " + typedInPart);
		}
		else
		{
			if (!atTokenEnd && onToken.tokenKind == SyntaxToken.Kind.Comment)
			{
				return false;
			}
			if (onToken != null && (
				onToken.tokenKind == SyntaxToken.Kind.StringLiteral ||
				onToken.tokenKind == SyntaxToken.Kind.VerbatimStringLiteral ||
				onToken.tokenKind == SyntaxToken.Kind.InterpolatedStringWholeLiteral ||
				onToken.tokenKind == SyntaxToken.Kind.InterpolatedStringStartLiteral ||
				onToken.tokenKind == SyntaxToken.Kind.InterpolatedStringMidLiteral ||
				onToken.tokenKind == SyntaxToken.Kind.InterpolatedStringEndLiteral ||
				onToken.tokenKind == SyntaxToken.Kind.InterpolatedStringFormatLiteral ||
				onToken.tokenKind == SyntaxToken.Kind.CharLiteral ||
				onToken.tokenKind == SyntaxToken.Kind.CharLiteral ||
				onToken.tokenKind >= SyntaxToken.Kind.Preprocessor &&
				onToken.tokenKind <= SyntaxToken.Kind.PreprocessorUnexpectedDirective))
			{
				return false;
			}
			//Debug.Log(onToken.tokenKind);
			
			startAtCharacterIndex = editor.caretPosition.characterIndex;
			lineIndex = editor.caretPosition.line;

			tokenLeft = editor.TextBuffer.GetNonTriviaTokenLeftOf(lineIndex, startAtCharacterIndex);
		}
		
		return true;
	}

	public static FGListPopup Create(FGTextEditor editor, Rect buttonRect, bool flipped)
	{
		if (listItemStyle == null)
		{
			LoadResources();
		}
		listItemStyle.fontSize = SISettings.fontSizeDelta + 11;
		listItemHeight = Mathf.Max(19f, listItemStyle.CalcHeight(new GUIContent(symbolIcons[0,0], "W"), 100f));
		listItemStyle.onNormal.textColor = editor.styles.normalStyle.normal.textColor;
		listItemStyle.normal.textColor = editor.styles.normalStyle.normal.textColor;
		
		FGListPopup window = CreatePopup<FGListPopup>();
		window.Flipped = flipped;
		window.minSize = new Vector2(1f, 1f);
		window.owner = EditorWindow.focusedWindow;

		startAtCharacterIndex = editor != null ? editor.caretPosition.characterIndex : 0;
		lineIndex = editor != null ? editor.caretPosition.line : 0;
		//tokenLeft = null;

		Vector2 screenPoint = GUIUtility.GUIToScreenPoint(
			new Vector2(buttonRect.x, flipped ? buttonRect.y : buttonRect.yMax));
		Rect position = new Rect(screenPoint.x - 24f - editor.charSize.x * typedInPart.Length,
			flipped ? screenPoint.y - 21f : screenPoint.y, 1f, 21f);
		window.dropDownRect = new Rect(position.x, flipped ? position.y + 21f : position.y - editor.LineHeight, 1f, editor.LineHeight);
		window.currentWidth = position.width;
		window.position = position;
		TypedInPart = typedInPart;

		window.ShowTooltip();

		return window;
	}

	private struct IndexNameTuple
	{
		public string name;
		public int index;
	}

	public static bool SetCompletionData(HashSet<SymbolDefinition> data)
	{
		FGListPopup.data = data.Where(s => !s.IsOperator).ToArray();

		var memberSymbols = new List<IndexNameTuple>();
		var localSymbols = new List<IndexNameTuple>();
		for (var i = FGListPopup.data.Length; i -- > 0;)
		{
			var symbol = FGListPopup.data[i];
			var kind = symbol.kind;
			if (kind == SymbolKind.Variable || kind == SymbolKind.Parameter || kind == SymbolKind.LocalConstant ||
				kind == SymbolKind.Label ||
				kind == SymbolKind.CatchParameter || kind == SymbolKind.FromClauseVariable ||
				kind == SymbolKind.ForEachVariable || kind == SymbolKind.CaseVariable ||
				kind == SymbolKind.OutVariable || kind == SymbolKind.IsVariable ||
				kind == SymbolKind.TupleDeconstructVariable)
			{
				var nameOf = NameOf(symbol);
				var recentIndex = recentCompletions.IndexOf(nameOf);
				localSymbols.Add(
					new IndexNameTuple
					{
						name = nameOf,
						index = recentIndex < 0 ? GetSymbolDeclarationLine(symbol) - lineIndex : recentIndex
					}
				);
			}
			else if (kind == SymbolKind.Field || kind == SymbolKind.Property || kind == SymbolKind.ConstantField || kind == SymbolKind.Event)
			{
				var nameOf = NameOf(symbol);
				var recentIndex = recentCompletions.IndexOf(nameOf);
				memberSymbols.Add(
					new IndexNameTuple
					{
						name = nameOf,
						index = recentIndex < 0 ? -i : recentIndex
					}
				);
			}
		}
		if (memberSymbols.Count > 0)
		{
			memberSymbols.Sort(OrderByIndex);
			for (var i = 0; i < memberSymbols.Count; ++i)
				AddRecentCompletion(recentCompletions, memberSymbols[i].name);
		}
		if (localSymbols.Count > 0)
		{
			localSymbols.Sort(OrderByIndex);
			for (var i = 0; i < localSymbols.Count; ++i)
				AddRecentCompletion(recentCompletions, localSymbols[i].name);
		}

		System.Array.Sort(FGListPopup.data, symbolDefinitionComparer);
		UpdateTypedInPart();
		
		return filteredData.Count > 0;
	}
	
	private static int OrderByIndex(IndexNameTuple a, IndexNameTuple b)
	{
		return a.index.CompareTo(b.index);
	}
	
	private static int GetSymbolDeclarationLine(SymbolDefinition symbol)
	{
		var firstDeclaration = symbol.declarations;
		if (firstDeclaration == null)
			return -1;
		var firstLeaf = firstDeclaration.parseTreeNode == null ? null : firstDeclaration.parseTreeNode.GetFirstLeaf();
		return firstLeaf == null ? -1 : firstLeaf.line;
	}
	
	public static void SetTopSuggestion(SymbolDefinition suggestion)
	{
		topSuggestion = suggestion.GetName();
	}

	private static FieldInfo scrollStepSizeField;
	
	private void Update()
	{
		if (completeOnUpdate)
		{
			completeOnUpdate = false;
			owner.SendEvent(Event.KeyboardEvent("\n"));
		}
	}
	
	public static Texture2D GetSymbolIcon(SymbolDefinition symbol)
	{
		if (symbolIcons == null)
			LoadSymbolIcons();
		
		var icon = symbol.cachedIcon;
		if (icon)
			return icon;
		
		icon = symbolIcons[
			(int) symbol.kind,
			symbol.IsPublic | symbol.IsInternal ? 0 : symbol.IsProtected ? 1 : 2] ?? keywordIcon;
		
		var asReflectedType = symbol as ReflectedType;
		if (asReflectedType != null && typeof(Component).IsAssignableFrom(asReflectedType.GetReflectedType()))
		{
			var unityContent = EditorGUIUtility.ObjectContent(null, asReflectedType.GetReflectedType());
			if (unityContent.image != null)
				icon = unityContent.image as Texture2D ?? icon;
		}
		
		symbol.cachedIcon = icon;
		return icon;
	}

	private static void AddRecentCompletion(List<string> list, string completion)
	{
		if (!list.Remove(completion) && list.Count == list.Capacity)
			list.RemoveAt(0);
		list.Add(completion);
	}

	private static readonly object boxedFloat1 = 1f;
	private static readonly object boxedFloat10 = 10f;

	private void OnGUI()
	{
		OnExternalGUI(Vector2.zero);
	}
	
	public void OnExternalGUI(Vector2 offset)
	{
		if (data == null || filteredData.Count == 0)
			return;
		
		if (Event.current.type == EventType.Layout)
			return;
		
		if (Event.current.type == EventType.ScrollWheel)
		{
			scrollPosition = Mathf.Clamp(scrollPosition + (int) Event.current.delta.y, 0, filteredData.Count - maxListItems);
			scrollPosition = Mathf.Clamp(scrollPosition, 0, Mathf.Max(0, filteredData.Count - maxListItems));
			Event.current.Use();
		}

		scrollViewRect = new Rect(offset.x, offset.y, currentWidth, position.height);
		FGTextEditor.FillRect(scrollViewRect, textEditor.styles.listFrameColor);

		scrollViewRect.xMin++;
		scrollViewRect.yMin++;
		scrollViewRect.xMax--;
		scrollViewRect.yMax--;

		FGTextEditor.FillRect(scrollViewRect, textEditor.styles.listBgColor);

		var rcScrollBar = new Rect(scrollViewRect);
		rcScrollBar.xMin = rcScrollBar.xMax - 15f;
		if (filteredData.Count > maxListItems)
		{
			object oldValue = boxedFloat10;
			if (Event.current.isMouse)
			{
				if (scrollStepSizeField == null)
				{
					scrollStepSizeField = typeof(GUI).GetField("scrollStepSize", System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Public);
				}
				if (scrollStepSizeField != null)
				{
					oldValue = scrollStepSizeField.GetValue(null);
					scrollStepSizeField.SetValue(null, boxedFloat1);
				}
			}
			
			if (scrollStepSizeField == null)
			{
				scrollPosition = (int)(0.1f * GUI.VerticalScrollbar(rcScrollBar, scrollPosition * 10f, maxListItems * 10f, 0, filteredData.Count * 10f));
			}
			else
			{
				scrollPosition = (int)GUI.VerticalScrollbar(rcScrollBar, scrollPosition, maxListItems, 0, filteredData.Count);
			}
			scrollPosition = Mathf.Clamp(scrollPosition, 0, Mathf.Max(0, filteredData.Count - maxListItems));

			if (Event.current.isMouse && scrollStepSizeField != null)
				scrollStepSizeField.SetValue(null, oldValue);
		}
		
		if (Event.current.type == EventType.MouseDown && Event.current.button == 0 &&
			(filteredData.Count <= maxListItems || Event.current.mousePosition.x < rcScrollBar.x))
		{
			var itemIndex = Mathf.Clamp((int) (Event.current.mousePosition.y / listItemHeight), 0, maxListItems - 1);
			currentItem = Mathf.Clamp(itemIndex + scrollPosition, 0, filteredData.Count - 1);
			//owner.Focus();

			Event.current.Use();

			if (Event.current.clickCount == 2)
			{
				completeOnUpdate = true;
				//owner.SendEvent(EditorGUIUtility.CommandEvent("ScriptInspector.Autocomplete=" + filteredData[currentItem].name));
			}

			//Repaint();
			return;
		}
		
		if (Event.current.type == EventType.Repaint)
		{
			var width = 100f;
			for (var i = Mathf.Min(filteredData.Count, scrollPosition + maxListItems) - 1; i >= scrollPosition; --i)
			{
				var itemContent = new GUIContent(ItemDisplayString(filteredData[i], "<b>" + filteredData[i].GetName() + "</b>"));
				if (filteredData[i].GetTypeParameters() != null)
					itemContent.text += "<>";
				width = Mathf.Max(width, listItemStyle.CalcSize(itemContent).x);
			}
			var pos = position;
			pos.width = currentWidth;
			var rc = pos;
			rc.width = Mathf.Max(rc.width, width + 24f + (filteredData.Count > maxListItems ? 21f : 2f));
			rc.height = listItemHeight * Mathf.Min(maxListItems, filteredData.Count) + 2f;
			if (!isSizeSet || rc != pos)
			{
				currentWidth = rc.width;
				pos = SetSize(rc.width, rc.height);
				position = pos;
				isSizeSet = true;
			}

			EditorGUIUtility.SetIconSize(new Vector2(16f, 16f));
			
			System.Text.StringBuilder sb = null;
			for (var i = Mathf.Min(filteredData.Count, scrollPosition + maxListItems); --i >= scrollPosition; )
			{
				var rcItem = new Rect(2f, 1f + listItemHeight * (i - scrollPosition), pos.width - 3f, listItemHeight);
				if (filteredData.Count > maxListItems)
					rcItem.xMax -= 15f;

				var on = i == currentItem;
				var focus = on || ~i == currentItem;
				var symbol = filteredData[i];
				var icon = GetSymbolIcon(symbol);
				var styledName = NameOf(filteredData[i]);
				if (matcher != null)
				{
					const string markerStart = "<b>";
					const string markerEnd = "</b>";
					
					var matches = matcher.GetMatch(styledName);
					if (matches != null && matches.Length > 0)
					{
						sb = sb ?? new System.Text.StringBuilder();
						sb.Length = 0;

						var isMatch = false;
						var m = 0;
						for (var s = 0; s < styledName.length; ++s)
						{
							if (m == matches.Length)
							{
								if (isMatch)
								{
									isMatch = false;
									sb.Append(markerEnd);
								}
								sb.Append(styledName, s, styledName.length - s);
								break;
							}
							if (s == matches[m])
							{
								++m;
								if (!isMatch)
								{
									sb.Append(markerStart);
									isMatch = true;
								}
							}
							else if (isMatch)
							{
								sb.Append(markerEnd);
								isMatch = false;
							}
							sb.Append(styledName[s]);
						}
						if (isMatch)
							sb.Append(markerEnd);
						styledName = sb.ToString();
					}
				}
				var displayString = ItemDisplayString(filteredData[i], styledName);
				var itemContent = new GUIContent(displayString, icon);
				if (filteredData[i].GetTypeParameters() != null)
					itemContent.text += "<>";
				rcItem.x += offset.x;
				rcItem.y += offset.y;
				if (Event.current.type == EventType.Repaint)
					listItemStyle.Draw(rcItem, itemContent, false, focus, focus, on);
			}
			
			EditorGUIUtility.SetIconSize(Vector2.zero);
		}

#if UNITY_2018_3_OR_NEWER
		if (focusedWindow == this && owner != null)
		{
			textEditor.FocusCodeView();
			//owner.Focus();
			//EditorApplication.delayCall += () => MoveInFrontOf(owner);
		}
#endif

		if (Event.current.type == EventType.ExecuteCommand || Event.current.type == EventType.ValidateCommand || Event.current.isKey)
			owner.SendEvent(Event.current);
	}

#if UNITY_2019_1_OR_NEWER
	// Called when the window loses keyboard focus.
	protected void OnLostFocus()
	{
		textEditor.CloseAutocomplete();
	}
#endif

	public SymbolDefinition OnOwnerGUI()
	{
		int focusedItem = currentItem;

		if (Event.current.type == EventType.ScrollWheel)
		{
			if (filteredData.Count <= maxListItems)
				return new SymbolDefinition();

			scrollPosition = Mathf.Clamp(scrollPosition + (int) Event.current.delta.y, 0, filteredData.Count - maxListItems);
			Event.current.Use();
			Repaint();
			return null;
		}

		if (Event.current.type == EventType.KeyDown)
		{
			var acceptWith = currentItem < 0 ? "\t" : "\t\n {}[]().,:;+-*/%&|^!~=<>?@\'\"\\";
			if (topSuggestion != null && currentItem >= 0 /*&& typedInPart == ""*/)
			{
				var currentSymbol = filteredData[currentItem];
				if (topSuggestion == currentSymbol.name)
				{
					if (currentSymbol.kind == SymbolKind.Enum)
						acceptWith = "\t\n.";
					else if (currentSymbol.kind == SymbolKind.Constructor || currentSymbol.kind == SymbolKind.Class || currentSymbol.kind == SymbolKind.Struct)
						acceptWith = "\t\n {(";
					else
						acceptWith = "\t\n";
				}
			}
			if (!(Event.current.alt || Event.current.command || Event.current.control) &&
				(acceptWith.IndexOf(Event.current.character) >= 0 || Event.current.keyCode == KeyCode.KeypadEnter))
			{
				if (Event.current.shift && Event.current.character == '\t')
					return new SymbolDefinition();
				if (currentItem < 0)
					currentItem = ~currentItem;
				var completion = NameOf(filteredData[currentItem]);
				recentCompletions.Clear();
				_recentCompletions.AddRange(savedRecentCompletions);
				AddRecentCompletion(_recentCompletions, completion);
				AddRecentCompletion(savedRecentCompletions, completion);
				var s = string.Join(",", recentCompletions.ToArray());
				EditorPrefs.SetString("ScriptInspectorRecentCompletions_1", s);
				return filteredData[currentItem];
			}

			switch (Event.current.keyCode)
			{
				//case KeyCode.Return:
				//    Event.current.Use();
				//    break;

				case KeyCode.Escape:
					Event.current.Use();
					return new SymbolDefinition();

				case KeyCode.UpArrow:
					if (Event.current.shift || Event.current.alt || Event.current.command || Event.current.control)
					{
						if (!Event.current.shift && !Event.current.alt)
							Event.current.modifiers = Event.current.modifiers & ~(EventModifiers.Control | EventModifiers.Command);
						return new SymbolDefinition();
					}
					Event.current.Use();
					if (currentItem >= 0)
						currentItem = Mathf.Max(0, currentItem - 1);
					else
						currentItem = Mathf.Max(0, -1-currentItem);
					break;

				case KeyCode.DownArrow:
					if (Event.current.shift || Event.current.alt || Event.current.command || Event.current.control)
					{
						if (!Event.current.shift && !Event.current.alt)
							Event.current.modifiers = Event.current.modifiers & ~(EventModifiers.Control | EventModifiers.Command);
						return new SymbolDefinition();
					}
					Event.current.Use();
					if (currentItem >= 0)
						currentItem = Mathf.Min(filteredData.Count - 1, currentItem + 1);
					else
						currentItem = Mathf.Min(filteredData.Count - 1, ~currentItem);
					break;

				case KeyCode.PageUp:
					Event.current.Use();
					if (currentItem >= 0)
						currentItem = Mathf.Max(0, currentItem - maxListItems);
					else
						currentItem = Mathf.Max(0, -10-currentItem);
					break;

				case KeyCode.PageDown:
					Event.current.Use();
					if (currentItem >= 0)
						currentItem = Mathf.Min(filteredData.Count - 1, currentItem + maxListItems);
					else
						currentItem = Mathf.Max(0, maxListItems + 1 - currentItem);
					break;

				//case KeyCode.Home:
				//	Event.current.Use();
				//	currentItem = 0;
				//	break;

				//case KeyCode.End:
				//	Event.current.Use();
				//	currentItem = filteredData.Count - 1;
				//	break;
			}
		}

		if (currentItem != focusedItem)
		{
			ScrollToCurrentItem();
			if (currentItem != -1)
			{
				scrollPosition = Mathf.Min(scrollPosition, currentItem);
				scrollPosition = Mathf.Max(scrollPosition, currentItem - maxListItems + 1);
			}
			Repaint();
		}

		if (textEditor.caretPosition.line != lineIndex)
			return new SymbolDefinition();
		if (textEditor.caretPosition.characterIndex < startAtCharacterIndex)
			return new SymbolDefinition();
		if (textEditor.caretPosition.characterIndex > startAtCharacterIndex + typedInPart.Length)
			return new SymbolDefinition();

		return null;
	}

	private void ScrollToCurrentItem()
	{
		int item = currentItem;
		if (item < 0)
			item = ~item;

		scrollPosition = Mathf.Min(scrollPosition, item);
		scrollPosition = Mathf.Max(scrollPosition, item - maxListItems + 1);

		Repaint();
	}

	private static void CenterScrollCurrentItem()
	{
		int index = currentItem;
		if (index < 0)
			index = ~index;

		scrollPosition = Mathf.Clamp(index - maxListItems / 2, 0, Mathf.Max(0, filteredData.Count - maxListItems));
	}
}

class BacktrackingStringMatcher
{
	readonly string filterTextUpperCase;
	readonly ulong filterTextLowerCaseTable;
	readonly ulong filterIsNonLetter;
	readonly ulong filterIsDigit;
	readonly string filterText;
	int[] cachedResult;

	public BacktrackingStringMatcher(string filterText)
	{
		this.filterText = filterText ?? "";
		if (filterText != null)
		{
			for (int i = 0; i < filterText.Length && i < 64; i++)
			{
				filterTextLowerCaseTable |= char.IsLower(filterText[i]) ? 1ul << i : 0;
				filterIsNonLetter |= !char.IsLetterOrDigit(filterText[i]) ? 1ul << i : 0;
				filterIsDigit |= char.IsDigit(filterText[i]) ? 1ul << i : 0;
			}

			filterTextUpperCase = filterText.ToUpper(CultureInfo.InvariantCulture);
		}
		else
		{
			filterTextUpperCase = "";
		}
	}

	public bool CalcMatchRank(CharSpan name, out int matchRank)
	{
		if (filterTextUpperCase.Length == 0)
		{
			matchRank = int.MinValue;
			return true;
		}
		var lane = GetMatch(name);
		if (lane != null)
		{
			if (name.length == filterText.Length)
			{
				matchRank = int.MaxValue;
				for (int n = 0; n < name.length; n++)
				{
					if (filterText[n] != name[n])
						matchRank--;
				}
				return true;
			}
			// exact named parameter case see discussion in bug #9114
			if (name.length - 1 == filterText.Length && name[name.length - 1] == ':')
			{
				matchRank = int.MaxValue - 1;
				for (int n = 0; n < name.length - 1; n++)
				{
					if (filterText[n] != name[n])
						matchRank--;
				}
				return true;
			}
			int capitalMatches = 0;
			int nonCapitalMatches = 0;
			int matching = 0;
			int fragments = 0;
			int lastIndex = -1;
			for (int n = 0; n < lane.Length; n++)
			{
				var ch = filterText[n];
				var i = lane[n];
				bool newFragment = i > lastIndex + 1;
				if (newFragment)
					fragments++;
				lastIndex = i;
				if (ch == name[i])
				{
					matching += 1000 / (1 + fragments);
					if (char.IsUpper(ch))
						capitalMatches += Mathf.Max(1, 10000 - 1000 * fragments);
				}
				else if (newFragment || i == 0)
				{
					matching += 900 / (1 + fragments);
					if (char.IsUpper(ch))
						capitalMatches += Mathf.Max(1, 1000 - 100 * fragments);
				}
				else
				{
					var x = 600 / (1 + fragments);
					nonCapitalMatches += x;
				}
			}
			matchRank = capitalMatches + matching - fragments + nonCapitalMatches + filterText.Length - name.length;
			// devalue named parameters.
			if (name[name.length - 1] == ':')
				matchRank /= 2;
			return true;
		}
		matchRank = int.MinValue;
		return false;
	}

	public bool IsMatch(string text)
	{
		int[] match = GetMatch(text);
		// no need to clear the cache
		cachedResult = cachedResult ?? match;
		return match != null;
	}

	int GetMatchChar(CharSpan text, int i, int j, bool onlyWordStart)
	{
		char filterChar = filterTextUpperCase[i];
		char ch;
		// filter char is no letter -> next char should match it - see Bug 674512 - Space doesn't commit generics
		var flag = 1ul << i;
		if ((filterIsNonLetter & flag) != 0)
		{
			for (; j < text.length; j++)
			{
				if (filterChar == text[j])
					return j;
			}
			return -1;
		}
		// letter case
		ch = text[j];
		bool textCharIsUpper = char.IsUpper(ch);
		if (!onlyWordStart && filterChar == (textCharIsUpper ? ch : ch.ToUpperAsciiInvariant()) && char.IsLetter(ch))
		{
			// cases don't match. Filter is upper char & letter is low, now prefer the match that does the word skip.
			if (!(textCharIsUpper || (filterTextLowerCaseTable & flag) != 0) && j + 1 < text.length)
			{
				int possibleBetterResult = GetMatchChar(text, i, j + 1, onlyWordStart);
				if (possibleBetterResult >= 0)
					return possibleBetterResult;
			}
			return j;
		}
		// no match, try to continue match at the next word start

		bool lastWasLower = false;
		bool lastWasUpper = false;
		int wordStart = j + 1;
		for (; j < text.length; j++)
		{
			// word start is either a upper case letter (FooBar) or a char that follows a non letter
			// like foo:bar
			ch = text[j];
			var category =
				ch <= 'Z' && ch >= 'A' ? System.Globalization.UnicodeCategory.UppercaseLetter
				: ch <= 'z' && ch >= 'a' ? System.Globalization.UnicodeCategory.LowercaseLetter
				: char.GetUnicodeCategory(ch);
			if (category == System.Globalization.UnicodeCategory.LowercaseLetter)
			{
				if (lastWasUpper && (j - wordStart) > 0)
				{
					if (filterChar == text[j - 1].ToUpperAsciiInvariant())
						return j - 1;
				}
				lastWasLower = true;
				lastWasUpper = false;
			}
			else if (category == System.Globalization.UnicodeCategory.UppercaseLetter)
			{
				if (lastWasLower)
				{
					if (filterChar == ch.ToUpperAsciiInvariant())
						return j;
				}
				lastWasLower = false;
				lastWasUpper = true;
			}
			else
			{
				if (filterChar == ch)
					return j;
				if (j + 1 < text.length && filterChar == text[j + 1].ToUpperAsciiInvariant())
					return j + 1;
				lastWasLower = lastWasUpper = false;
			}
		}
		return -1;
	}

	/// <summary>
	/// Gets the match indices.
	/// </summary>
	/// <returns>
	/// The indices in the text which are matched by our filter.
	/// </returns>
	/// <param name='text'>
	/// The text to match.
	/// </param>
	public int[] GetMatch(CharSpan text)
	{
		if (string.IsNullOrEmpty(filterTextUpperCase))
			return new int[0];
		if (text.IsEmpty || filterText.Length > text.length)
			return null;
		int[] result;
		if (cachedResult != null)
		{
			result = cachedResult;
		}
		else
		{
			cachedResult = result = new int[filterTextUpperCase.Length];
		}
		int j = 0;
		int i = 0;
		bool onlyWordStart = false;
		while (i < filterText.Length)
		{
			if (j >= text.length)
			{
				if (i > 0)
				{
					j = result[--i] + 1;
					onlyWordStart = true;
					continue;
				}
				return null;
			}

			j = GetMatchChar(text, i, j, onlyWordStart);
			onlyWordStart = false;
			if (j == -1)
			{
				if (i > 0)
				{
					j = result[--i] + 1;
					onlyWordStart = true;
					continue;
				}
				return null;
			}
			else
			{
				result[i] = j++;
			}
			i++;
		}
		// clear cache
		cachedResult = null;
		return result;
	}
}

}
